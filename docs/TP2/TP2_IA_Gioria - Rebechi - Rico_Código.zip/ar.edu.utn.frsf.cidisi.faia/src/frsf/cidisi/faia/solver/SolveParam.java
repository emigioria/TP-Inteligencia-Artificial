package frsf.cidisi.faia.solver;

public abstract class SolveParam {

}
