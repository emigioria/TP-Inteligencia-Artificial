package frsf.cidisi.exercise.patrullero.search;

public interface ChangeListenerPatrullero {

	public Boolean cambio();

	public void finSimulacionExitosa();

	public void finSimulacionNoExitosa();

}
