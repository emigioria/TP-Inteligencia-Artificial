package frsf.cidisi.faia.solver.productionsystem;

import java.util.List;

public interface ProductionMemory {

	List<Rule> getRules();

}