package frsf.cidisi.exercise.patrullero.search.modelo;

public enum NombreObstaculo {
	CORTE, ACCIDENTE, CONGESTION, EVENTO_SOCIAL, BACHEO
}
