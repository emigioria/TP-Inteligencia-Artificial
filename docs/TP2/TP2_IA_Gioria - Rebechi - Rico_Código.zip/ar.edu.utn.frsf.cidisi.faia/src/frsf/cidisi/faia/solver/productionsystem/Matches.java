package frsf.cidisi.faia.solver.productionsystem;

public interface Matches {

	@Override
	public boolean equals(Object obj);

	@Override
	public int hashCode();
}
